#
# Regular cron jobs for the tolua++ package
#
0 4	* * *	root	tolua++_maintenance
